#define START 0
#define COMMENT 1
#define UDP 2
#define UDPCOMMENT 3
